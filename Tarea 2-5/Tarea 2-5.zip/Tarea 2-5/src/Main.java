//Realizado por Daniel Rubio
public class Main {

	public static void main(String[] args) {
		
		new Calculadora("Calculadora");

	}

}

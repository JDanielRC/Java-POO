public class Figura {

    protected String color;

    public String getColor() {return color;}


    public Figura(String color){
        this.color = color;
    }

    public Figura() {
        color = "azul";
    }


}

public class ExcepcionPoligono extends Exception {

    public ExcepcionPoligono(){
        super("Excepción lanzada");
    }

}

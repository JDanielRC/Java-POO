public class clockException extends Exception{

  public clockException(){
    super("Ocurrió una excepción.");
  }
}

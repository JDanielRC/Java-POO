//actividad realizada Juan Daniel Rubio Camacho A01633924
public class Eye {

    public Eye() {
        System.out.println("Constructor Default.");
    }
    public void blink() {
        System.out.println("*blink* *blink*");
    }
}

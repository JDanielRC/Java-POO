//Juan Daniel Rubio Camacho A01633924
public class Main {

	public static void main(String[] args) {
		
		Robot r1 = new Robot("Prime", 1999, "Optimus");
		DeliveryPlane dp1 = new DeliveryPlane("Avionsin", 2005, 3.5f);
		DeliveryDrone dd1 = new DeliveryDrone("Bombol", 2003, "Bee", 4);
		Mailman m1 = new Mailman("Pepe");
		System.out.println(MailOffice.getFastestDelivery(dp1, dd1) + " es el m�s r�pido.");
		System.out.println(MailOffice.getFastestDelivery(dp1, m1) + " es el m�s r�pido.");
		System.out.println(MailOffice.getFastestDelivery(m1, dd1) + " es el m�s r�pido.");
		System.out.println(MailOffice.getNewerRobot(r1, dd1) + " es el robot m�s nuevo.");


	}

}

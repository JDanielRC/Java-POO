//Juan Daniel Rubio Camacho A0163392
public interface Transporter {
	
	public float calculateSpeed();
	public String stateYourName();
	
}
